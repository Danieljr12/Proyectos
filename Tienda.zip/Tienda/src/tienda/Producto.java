
package tienda;

public class Producto {
    private String nombre;
    private String marca;
    private double descuento;
    private double precio;
    private boolean stock;
    private String imagen;

    public Producto() {
    }

    public Producto(String nombre, String marca, double descuento, double precio, boolean stock, String imagen) {
        this.nombre = nombre;
        this.marca = marca;
        this.descuento = descuento;
        this.precio = precio;
        this.stock = stock;
        this.imagen = imagen;
    }

   

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public boolean isStock() {
        return stock;
    }

    public void setStock(boolean stock) {
        this.stock = stock;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }
    
    
    
}
