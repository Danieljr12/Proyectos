
package tienda;

import java.util.ArrayList;
public class Control {
    
    private static ArrayList<Object> prods = new ArrayList<Object>();

    public Control() {

        Prendas prenda = new Prendas(
                "Camiseta lujo","S",
                "camisa vinotinto",
                "Nike",0,2000,
                true,"/imagenes/camisa1.jpg");
        
        Prendas prenda1 = new Prendas(
                "Camisa","S",
                "camisa fucsia",
                "Adidas",0,3000,
                true,"/imagenes/camisa2.jpg");
        
        Prendas prenda2 = new Prendas(
                "Camisa","S",
                "camisa rosada",
                "Adidas",0,3000,
                true,"/imagenes/camisa3.jpeg");
        
        Prendas prenda3 = new Prendas(
                "Pantalon","S",
                "Pantalon amarillo",
                "Diesel",0,4000,
                true,"/imagenes/pantalon1.jpeg");
        
        Prendas prenda4 = new Prendas(
                "Pantalon","S",
                "Jean azul",
                "Diesel",0,3000,
                true,"/imagenes/pantalon2.jpg");
        
        Prendas prenda5 = new Prendas(
                "Pantalon","S",
                "Pantalon azul",
                "Gino pascalli",0,3000,
                true,"/imagenes/pantalon3.jpeg");
        
        Cremas crema = new Cremas(100,"crema hidratante","Ponds", 0,3000,true,"/imagenes/crema1.jpg");
        Cremas crema1 = new Cremas(100,"crema para pelo","dove", 0,2500,true,"/imagenes/crema2.jpeg");
        Cremas crema2 = new Cremas(100,"crema para pelo","dove", 0,2500,true,"/imagenes/crema2.jpeg");

        this.prods.add(prenda);
        this.prods.add(prenda2);
        this.prods.add(prenda2);
        this.prods.add(prenda3);
        this.prods.add(prenda4);
        this.prods.add(prenda5);
        this.prods.add(crema);
        this.prods.add(crema1);
        this.prods.add(crema2);
        
        
    }

    public static ArrayList<Object> getProds() {
        return prods;
    }

    public static void setProds(Object prods) {
        Control.prods.add(prods);
    }
    
    
    
    
    
}
