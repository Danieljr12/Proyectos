
package tienda;


public class Tienda {

    public static void main(String[] args) {

        new Principal().setVisible(true);

        
    }
    
}
