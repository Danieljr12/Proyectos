
package tienda;

public class Cremas extends Producto {
 
    private int cantidad;

    public Cremas() {
    }

    public Cremas(int cantidad) {
        this.cantidad = cantidad;
    }

    public Cremas(int cantidad, String nombre, String marca, double descuento, double precio, boolean stock, String imagen) {
        super(nombre, marca, descuento, precio, stock, imagen);
        this.cantidad = cantidad;
    }

    

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
    
    
    
}
