
package tienda;

public class Prendas extends Producto {
    private String tipo;
    private String talla;

    public Prendas(){
        super();
    }

    public Prendas(String tipo, String talla) {
        this.tipo = tipo;
        this.talla = talla;
    }

    public Prendas(String tipo, String talla, String nombre, String marca, double descuento, double precio, boolean stock, String imagen) {
        super(nombre, marca, descuento, precio, stock, imagen);
        this.tipo = tipo;
        this.talla = talla;
    }

    
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }
    
    
    
    
}
